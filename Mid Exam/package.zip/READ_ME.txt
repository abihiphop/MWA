Instructions to use the application.
1. Run node server
2. browse http://localhost:3000/#/ 
    Note: You can change the port from 3000 to whatever you need, in line 8 of the app.js file
3. The above url will take you to the home page and show you a welcome.html page that has two links("View All Cities" and "Add New City" )
4. follow the links on the GUI to perform add,delete,edit,see detail of a city or search using city or state
5. Note: Searching the cities may take time since it fetches all the >25K documents, limiting the results from the back end is possible but, cities which are 
not in the limit could not be searched
    
