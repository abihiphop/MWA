angular.module("CitiesApp").controller("CitiesListController", CitiesListController);

function CitiesListController(CitiesFactory) {
  var This = this;
   CitiesFactory.getAllCities().then(function (response) {
    This.CitiesContent = response;
  });
}
