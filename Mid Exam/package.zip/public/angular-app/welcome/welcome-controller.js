// angular.module("JobsApp").controller("WelcomeController", WelcomeController);

// function WelcomeController(JobsFactory) {
//   var This = this;
//   JobsFactory.getAllJobs().then(function (response) {
//     This.JobsContent = response;
//   });
// }


